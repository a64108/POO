# ========================================================================
# UALG - POO 
# Aluno - 64108
# Exercicio - 6 - C
# ========================================================================

# Faça uma função que escreve uma string, passada como argumento, na vertical.

def print_vertically(texto):
    for char in texto:
        print(char)

texto = input("Introduzir texto: ")
print_vertically(texto)





